<?php
        $conn = mysqli_connect("localhost","root","","db_login")
        or die ("koneksi gagal");
?>