<?php

$conn = mysqli_connect("localhost", "root", "", "ngobar") or die("Koneksi gagal");